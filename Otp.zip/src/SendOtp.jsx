import axios from "axios";
import React, { Component } from "react";
import Button from "@material-ui/core/Button";
import Typography from "@material-ui/core/Typography";
// import idGenerator from "react-id-generator";
import OTP from "otp-client";
import "bootstrap/dist/css/bootstrap.min.css";
import Swal from "sweetalert2";
// import InputAdornment from "@material-ui/core/InputAdornment";
// import Card from "@material-ui/core/Card";
// import { withStyles } from "@material-ui/core/styles";



class Otp extends Component {
  state = {
    phoneNo: "",
    // multiline: "Controlled",
    enterOtp: "",
    // otp: idGenerator("REACTOTP"),
    verified: "",
  };

  componentDidMount() {
    const secret = "TPQDAHVBZ5NBO5LFEQKC7V7UPATSSMFY";
    const options = {
      algorithm: "sha256",
      digits: 4,
      period: 20,
    };

    const otp = new OTP(secret, options);
    const token = otp.getToken();
    this.setState({ otp: token });
    console.log("working", this.state.otp);
  }

  handleChange = (name) => (event) => {
    this.setState({
      [name]: event.target.value,
    });
  };

  sendOtpHandler = () => {
    console.log("logged", this.state.name);

    console.log("otp", this.state.otp);

    // const params = {
    //   apikey: "P+uEzfbqb0I-5LZubEfVBlAa41jcKaE9N7LbHUUM71",
    //   numbers: "91" + this.state.phoneNo,
    //   message: "Your OTP is " + this.state.otp,
    // };
    axios
      .get('http://192.168.107.101:5051/getstatelist')
      
      .then((response) => {
        console.log(response);
      })
      .catch((error) => {
        console.log(error);
      });
    // alert("----OTP send----");
  };
  verifiyOtpHandler = () => {
    if (this.state.enterOtp === this.state.otp) {
      // return this.setState({ verified: true });
      // this.props.navigate("/home");
    }
    if (this.state.enterOtp !== this.state.otp) {
      return this.setState({ verified: false });
      // this.props.navigate("/home");
    }
    // alert("verify success");
    Swal.fire({
      title: "Success",
      icon: "success",
      confirmButtonText: "OK",
    }).then(function () {
      window.location.href= "/home";
    });
  };

  render() {
    // const { classes } = this.props;
    return (
      <div className="form-wrapper">

        <h2>OTP-Verification</h2>
        <h5 className="m-0">Mobile phone verification</h5>
        <span className="mobile-text">
          Enter the code send on your phone
          <a className="text-danger">+91XXXXXX0000</a>
        </span>
        <span className="text" href to="Change mobile number">Change mobile number</span>

        <div className="otp">

          {/* <input
            placeholder="Enter your number"
            value={this.state.phoneNo}
            onChange={this.handleChange("phoneNo")}
            margin="normal"
            variant="outlined"
            type="number"
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">+91</InputAdornment>
            ),
          }}
          /> */}
        </div>
        <div className="otp">

          {/* <Button
            onClick={this.sendOtpHandler}
            color="primary">
            Send otp
          </Button> */}

          <input
            placeholder="Enter OTP"
            variant="outlined"
            value={this.state.enterOtp}
            onChange={this.handleChange("enterOtp")}
            margin="normal"
          />

          <Button
            className="btn-btn-primary btn-lg"
            variant="outlined"
            type="number"
            onClick={this.verifiyOtpHandler}
            // onChange={this.showAlert}
            color="primary"
          >
            Verifiy
          </Button>
        </div>
        <div>
          <div >
            {this.state.verified.showAlert === true ? (
              <Typography>
                {/* <button onClick={this.showAlert}>Success</button>  */}
              </Typography>
            ) : (
              <Typography></Typography>
            )}

            {this.state.verified === false ? (
              <Typography>Invalid Otp</Typography>
            ) : (
              <Typography></Typography>
            )}
          </div>
        </div>
      </div>

      // </div>
    );
  }
}

export default (Otp);
        // withStyles(styles)
