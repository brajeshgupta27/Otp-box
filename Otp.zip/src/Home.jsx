import React from "react";
import FileUplode from "./FileUplode";


export default function Home() {
    const [name, setName] = React.useState("");
    const [highest, setHighest] = React.useState("");
    const [aadhar, setAadhar] = React.useState("");
    const [pan, setPan] = React.useState("");
    const [bankAc, setBankAc] = React.useState("");
    const [ifsc, setIfsc] = React.useState("");
    const [branch, setBranch] = React.useState("");


    const handleSubmit = async (event) => {
        console.log(`
            name:${name}
            highest:${highest}
            aadhar:${aadhar}
            pan:${pan}
            bankAc:${bankAc}
            ifsc:${ifsc}
            branch:${branch}
        `);
        event.preventDefault();
    }


    return (
        <div className="wrapper1">

            <div className="form-wrapper1">
                <h3 className="text-center"><b>Bank Details</b></h3>
                <form onSubmit={handleSubmit}>

                    <div className="firstName">
                        <label className="lastName">
                            <b>Full Name</b>
                            <input
                                type="text"
                                placeholder="Enter your full name"
                                value={name}
                                onChange={event => setName(event.target.value)}
                                required />
                        </label>

                        <label className="lastName">
                            <b>Highest Qulification*</b>

                            <input
                                name="Highest Qulification"
                                type="text"
                                placeholder="Enter your highest qulification*"
                                value={highest}
                                onChange={event => setHighest(event.target.value)}
                                required />
                        </label>

                        <label className="lastName">
                            <b>Aadhar Number</b>

                            <input
                                name="aadhar"
                                type="number"
                                placeholder="Enter your aadar number"
                                value={aadhar}
                                onChange={event => setAadhar(event.target.value)}
                                required />
                        </label>
                        <label className="lastName">
                            <b>Pan Number</b>

                            <input
                                name="pan"
                                type="text"
                                placeholder="Enter your Pan number"
                                value={pan}
                                onChange={event => setPan(event.target.value)}
                                required />
                        </label>
                        <label className="lastName">
                            <b>Bank Ac</b>

                            <input
                                name="bankAc"
                                type="number"
                                placeholder="Enter your bank Account number"
                                value={bankAc}
                                onChange={event => setBankAc(event.target.value)}
                                required />
                        </label>
                        <label className="lastName">
                            <b>IFSC Code</b>
                            <input
                                name="ifsc code"
                                type="text"
                                placeholder="Enter your IFSC code"
                                value={ifsc}
                                onChange={event => setIfsc(event.target.value)}
                                required />
                        </label>
                        <label className="lastName">
                            <b>Branch</b>
                            <input
                                name="branch"
                                type="text"
                                placeholder="Enter your branch location"
                                value={branch}
                                onChange={event => setBranch(event.target.value)}
                                required />
                        </label>
                    </div>

                    <div className="createAccount1">
                        <FileUplode />
                        <button type="submit" onClick={handleSubmit}>Submit</button>
                    </div>
                </form>
            </div>
        </div>
    );
}