import React, { Component } from "react";
import SendOtp from "./SendOtp";
import axios from "axios";
import "bootstrap/dist/css/bootstrap.min.css";
// import { formValidate } from './Validator';

class Login extends Component {
  constructor(props) {
    super(props);
    this.state = {
      ppersons: [],
      firstName: null,
      email: null,
      mobile: {
        required: true,
        maxlength: 10,
        number: true,
      },
      state: null,

      openModal: false,
    };
  }
  // Api call by fetch method

  componentDidMount() {
    let posState = [];
    axios.get("http://192.168.107.101:5051/getstatelist").then((res) => {
      console.log(res.data);
      posState = res.data.result.map((pp) => {
        return pp;
      });
      console.log(posState);
      this.setState({ ppersons: posState });
    });
  }

  handleSubmit = (e) => {
    e.preventDefault();
    this.setState({ openModal: true });
    if (this.state.mobile) {
    } else {
    }
  };

  //   mobile(number){
  //     var mobile=number;
  //     if(mobile.length!=10){
  //         return false;
  //     }
  //     Regex = /[0-9 -()+]+$/;
  //     mobile=true;
  //     for ( var i=0; i < 10; i++) {
  //         if(Regex.test(mobile[i]))
  //              {
  //              continue;
  //              }
  //             else{
  //                 mobile=false;
  //                 break;
  //             }
  //          }
  //     return mobile;
  // }

  // mobile =()=>{
  //           var filter = /^((\+[1-9]{1,4}[ \-]*)|(\([0-9]{2,3}\)[ \-]*)|([0-9]{2,4})[ \-]*)*?[0-9]{3,4}?[ \-]*[0-9]{3,4}?$/;

  //           if (filter.test(mobile)) {
  //             if(mobile.length==10){
  //                  var validate = true;
  //             } else {
  //                 alert('Please put 10  digit mobile number');
  //                 var validate = false;
  //             }
  //           }
  //           else {
  //             alert('Not a valid number');
  //             var validate = false;
  //           }
  //         }
  render() {
    return (
      <div className="wrapper">
        {this.state.openModal ? (
          <>
            <div
              className="d-flex align-items-center justify-content-center"
              style={{
                height: "00vh",
                width: "00vw",
                position: "absolute",
                opacity: 15,
                justifyContent: "center",
                alignItems: "center",
                // boxShadow: "0px 0px 0px #ffff",
              }}
            >
              <div
                style={{
                  justifyContent: "center",
                  alignItems: "center",
                  textAlign: "center",
                }}
              >
                <SendOtp {...this.props} />
              </div>
            </div>
          </>
        ) : null}

        {/* //{console.log(this.state.ppersons, "abcg")} */}
        <div className="form-wrapper">
          <h3 className="text-center">Login</h3>
          <form onSubmit={this.handleSubmit}>
            <div className="firstName"></div>
            <label className="lastName">
              <b>First Name</b>
              <input
                placeholder="Enter your first name"
                type="text"
                name="firstName"
                noValidate
                onChange={this.handleChange}
              />
            </label>

            <label className="lastName">
              <b>Last Name</b>
              <input
                placeholder="Enter your last name"
                type="text"
                name="LastName"
                noValidate
                onChange={this.handleChange}
              />
            </label>

            <label className="lastName">
              <b>Email</b>
              <input
                placeholder="Enter your email"
                type="email"
                name="email"
                noValidate
                onChange={this.handleChange}
              />
            </label>

            <label className="lastName">
              <b>Mobile</b>
              <input
                placeholder="Enter your mobile number"
                type="number"
                name="Mobile"
                noValidate
                onChange={this.handleChange}
              />
            </label>         
            <select className="select">
              <option>Select State</option>
              {this.state.ppersons.map((ppp, index) => (
                <option key={index} value={ppp.pospStateId}>
                  {ppp.pospStateName}
                </option>
              ))}
            </select>

            <div className="createAccount">
              <button type="submit">Submit</button>
            </div>
          </form>
        </div>
      </div>
    );
  }
}
export default Login;
