import React from "react";

const Footer = () => {
    return (
        <footer>
            <p className="px-5 text-center disclaimer">
                License No. 634, IRDA Composite Broker Code: IRDA/ CB 691/17, Valid
                till: 10/12/2023, CIN: U66000DL2016PTC292037, Principal Officer: PK
                Bhagat
            </p>
            <p className="px-5 text-center disclaimer">
                Disclaimer: Insurance is the Subject matter of Solicitation. For more
                details on risk factors, Terms & Conditions please read the sales
                brochure carefully before purchasing the policy.
            </p>
            <p className="text-center">
                © GramCover 2016-2022. All rights reserved.&nbsp;
                <a
                    className="text-reset fw-bold"
                    href="https://www.gramcover.com/sell-insurance"
                >
                    gramcover.com
                </a>{" "}
            </p>
        </footer>
    );
};

export default Footer;
