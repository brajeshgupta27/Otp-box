import "bootstrap/dist/css/bootstrap.min.css";
import React, { useEffect, useState, setState } from 'react';
import axios from 'axios';


export default function Log() {
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [email, setEmail] = useState('');
  const [mobile, setMobile] = useState('');
  const [password, setPassWord] = useState('');
  const [posstate, setPosState] = useState(null);

  const handleSubmit = e => {
    e.preventDefault();
    const data = {
      first_name: firstName,
      last_name: lastName,
      email: email,
      mobile: mobile,
      password: password
    };
    console.log(data);
  };

  React.useEffect(() => {
    let posState = [];
      axios.get("http://192.168.107.101:5051/getstatelist").then((res) => {
        console.log(res.data);
        posState = res.data.result.map((pp) => {
          return pp;
        });
        console.log(posState);
        // this.setState({ ppersons: posState });
      });
  },[]);


  return (
    <div className="wrapper">
      <form onSubmit={handleSubmit} >
        <div className="form-wrapper">
          <h3>Posp Login</h3>

          <div className="firstName">
            <label className="lastName">First Name</label>
            <input type="text"
              placeholder="First Name"
              value={firstName}
              onChange={e => setFirstName(e.target.value)} />


            <label className="lastName">Last Name</label>
            <input type="text"
              placeholder="Last Name"
              value={lastName}
              onChange={e => setLastName(e.target.value)} />


            <label className="lastName">Email</label>
            <input type="email"
              placeholder="Email"
              onChange={e => setEmail(e.target.value)} />


            <label className="lastName">Mobile</label>
            <input type="number"
              placeholder="Mobile"
              onChange={e => setMobile(e.target.value)} />


            <label className="lastName">Password</label>
            <input type="password"
              placeholder="Password"
              onChange={e => setPassWord(e.target.value)} />

            <div>
              {/* {console.log(this.state.ppersons, "abcg")} */}

              <select className="select">
                <option>---Select State---</option>
                {/* {
            this.state.ppersons.map((ppp, index) => (            
                <option key={index} value={ppp.pospStateId}>
                  {ppp.pospStateName}
                </option>
            ))
          } */}
              </select>
              <div className="createAccount">
                <button type="submit">Submit</button>
              </div>
            </div>
          </div>
        </div>
      </form>
    </div>
  );
}





































// const Log = () => {
//   const [name, setName] = React.useState("");
//   const [email, setEmail] = React.useState("");
//   const [mobile, setMobile] = React.useState("");
//   // const [state, setState] = React.useState("");

//   const handleSubmit = async (event) => {
//     console.log(`
//           name:${name}
//           email:${email}
//           mobile:${mobile}
//       `);
//     event.preventDefault();
//   }

//   useEffect(() => {
//     axios.get("http://192.168.107.101:5051/getstatelist")
//       .then((response) => console.log(response.data));
//   }, []);

//   // useEffect(() => {
//   //   let posState = [];
//   //   axios.get("http://192.168.107.101:5051/getstatelist").then((res) => {
//   //     console.log(res.data);
//   //     posState = res.data.result.map((pp) => {
//   //       return pp;
//   //     });
//   //     console.log(posState);
//   //     this.setState({ ppersons: posState });
//   //    } );
//   // }

//   return (
//     <div className="wrapper">
//       <div className="form-wrapper">
//         <h3 className="text-center"> <b> Posp Login </b> </h3>
//         <form onSubmit={handleSubmit}>

//           <div className="firstName">
//             <label className="lastName">
//               <b>Name</b>
//               <input
//                 type="text"
//                 placeholder="Enter your full name"
//                 value={name}
//                 onChange={event => setName(event.target.value)}
//                 required />
//             </label>

//             <label className="lastName">
//             <b> Email : </b>
//               <input
//                 type="email"
//                 placeholder="email@gmail.com"
//                 value={email}
//                 onChange={event => setEmail(event.target.value)}
//                 required />
//             </label>

//             <label className="lastName">
//             <b> Mobile : </b>
//               <input
//                 type="number"
//                 placeholder="9876543210"
//                 value={mobile}
//                 onChange={event => setMobile(event.target.value)}
//                 required
//               />
//             </label>
//             {/* {console.log(this.state.ppersons, "abcg")} */}

//             <select className="select">
//               <option>select state</option>
//               {/* {
//             this.state.ppersons.map((ppp, index) => (
//               <option key={index} value={ppp.pospStateId}>
//                 {ppp.pospStateName}
//               </option>
//             ))
//           } */}
//             </select>
//             <div className="createAccount">
//               <button type="submit">Submit</button>

//             </div>
//           </div>
//         </form>

//       </div>
//     </div>
//   );
// }

// export default Log;
