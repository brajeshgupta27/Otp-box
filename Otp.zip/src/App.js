import React, { Component } from "react";
import { Routes, Route } from "react-router-dom";
import Login from "./Login";
import Home from "./Home";
import "./App.css";
import Header from "./Header";
// import LoginPosp from "./LoginPosp";
// import Log from "./Log";

export default class App extends Component {
  render() {
    return (
      <div>
        <Header />
        <Routes>
          <Route path="/" element={<Login {...this.props} />} />
          <Route path="/home" element={<Home />} />
        </Routes>
          {/* <LoginPosp /> */}
        {/* <Footer /> */}
      </div>
    );
  }
}
