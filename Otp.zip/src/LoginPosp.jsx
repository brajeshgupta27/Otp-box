import React from 'react';

const LoginPosp = () => {
    const [userName, setUserName] = React.useState("");
    const [password, setPassword] = React.useState("");

    const handleSubmit = async (event) => {
        console.log(`
            username : ${userName}
            password : ${password}          
        `);
        event.preventDefault();
    }

    return (
        <div className="wrapper">
            <div className="form-wrapper">
                <h2 className="text-center">Login Posp Details</h2>

                <form onSubmit={handleSubmit}>
                    <div className="row mb-3">
                        <label>
                            User Name : {" "}
                            <input
                                type="text"
                                placeholder="Enter your full name"
                                value={userName}
                                onChange={event => setUserName(event.target.value)}
                                required />
                        </label>
                    </div>

                    <div>
                        <label>
                            Password : {" "}
                            <input
                                type="password"
                                value={password} 
                                onChange={event => setPassword(event.target.value)}
                                required
                            />
                        </label>
                    </div>
                    <div className="createAccount">
                        <button type="submit" onClick={handleSubmit}>Submit</button>
                    </div>
                </form>
            </div>
        </div>
    );
}

export default LoginPosp;
