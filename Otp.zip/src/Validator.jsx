export const formValidate = (inputs) => {

    const errors = {};

    //console.log(inputs,"asasas");

    if (!inputs.name) {
        errors.name = 'Please enter name';
    }

    if (!inputs.email) {
        errors.email = 'Please enter email';
    } else if (!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(inputs.email)) {
        errors.email = 'Invalid email address';
    }

    if (!inputs.mobile) {
        errors.mobile = 'Please enter mobile';
    } else if (inputs.mobile.length < 10) {
        errors.mobile = 'Please enter 10 digit mobile no.';
    } else if (!/^(?:(?:\+|0{0,2})91(\s*[\-]\s*)?|[0]?)?[6789]\d{9}$/.test(inputs.mobile)) {
        errors.mobile = 'Invalid mobile no.';
    }

    if (!inputs.gender) {
        errors.gender = 'Please select gender';
    }
    
    if (!inputs.dateOfBirth) {
        errors.dateOfBirth = 'Please select dob';
    }

    if (!inputs.pan) {
        errors.pan = 'Please enter pan no.';
    } else if (inputs.pan.length < 10) {
        errors.pan = 'Please enter 10 digit pan no.';
    } else if (!/^([a-zA-Z]){5}([0-9]){4}([a-zA-Z]){1}?$/.test(inputs.pan)) {
        errors.pan = 'Invalid pan no.';
    }
    if (!inputs.occupation) {
        errors.occupation = 'Please select occupation';
    }
    if (!inputs.maritalStatus) {
        errors.maritalStatus = 'Please select marital status';
    }
    if (!inputs.addressOne) {
        errors.addressOne = 'Please enter address1';
    }
    if (!inputs.addressTwo) {
        errors.addressTwo = 'Please enter address2';
    }
    if (!inputs.pincode) {
        errors.pincode = 'Please enter pincode';
    } else if (inputs.pincode.length < 6) {
        errors.pincode = 'Please enter 6 digit pincode.';
    }
    if (!inputs.stateId) {
        errors.stateId = 'Please enter state';
    }
    if (!inputs.nomineeName) {
        errors.nomineeName = 'Please enter nominee name';
    }
    if (!inputs.nomineeDOB) {
        errors.nomineeDOB = 'Please select nominee dob';
    }
    if (!inputs.nomineeRelation) {
        errors.nomineeRelation = 'Please select customer relation';
    }
    ///
    //Password Errors

    return errors;
}

export const vehicleDetailFormValidate = (inputs) => {

    const errors = {};

    if (!inputs.registrationNoFirst) {
        errors.registrationNoFirst = 'Please enter vehicle registration no.';
    }

    if (!inputs.registrationNoLast) {
        errors.registrationNoLast = 'Please enter vehicle registration no.';
    }
    if (!inputs.engineNo) {
        errors.engineNo = 'Please enter vehicle engine no.';
    } else if (inputs.engineNo.length < 6) {
        errors.engineNo = 'Minimum 6 characters required';
    }
    if (!inputs.chasisNo) {
        errors.chasisNo = 'Please Enter Vehicle Chasis No.';
    } else if (inputs.chasisNo.length < 17) {
        errors.chasisNo = "Minimum 17 characters required";
    }
    if (!inputs.financer) {
        errors.financer = 'Please select financer';
    }
    if (!inputs.financerType) {
        errors.financerType = 'Please select financer type';
    }
    if (!inputs.financerBranch) {
        errors.financerBranch = 'Please enter financer branch/city';
    }
    ///financerBranch
    //Password Errors

    return errors;
}

export const PreviousPolicyAndCPADetailsFormValidate = (inputs) => {

    const errors = {};

    if (!inputs.previousInsurerId) {
        errors.previousInsurerId = 'Please select previous insurer';
    }

    if (!inputs.previousPolicyNo) {
        errors.previousPolicyNo = 'Please enter policy no.';
    }
    if (!inputs.cpaOtpReason) {
        errors.cpaOtpReason = 'Please select CPA opt-out reason';
    }

    return errors;

}